# Blue Pages - Book Review Blog

A beginner-friendly responsive book review blog built with HTML, CSS and JavaScript.

## Files
- `index.html` - homepage
- `the-hunger-games.html`
- `pride-and-prejudice.html`
- `ikigai.html`
- `to-kill-a-mockingbird.html`
- `the-boy-in-striped-pyjamas.html`
- `style.css` - all styling
- `script.js` - small JavaScript interactions

## GitHub Pages setup
1. Create/sign in to your GitHub account.
2. Create a new repository, for example `book-review-blog`.
3. Keep the repository Public if you are using the free GitHub Pages option.
4. Upload all the files in this folder to the repository root. Do not upload the folder itself as an extra nested folder.
5. Open the repository's **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select the `main` branch and the `/ (root)` folder, then click **Save**.
8. Wait for GitHub to publish the site.
9. Your site will normally be available at:
   `https://YOUR-USERNAME.github.io/book-review-blog/`
10. If you edit files later, commit the changes and GitHub Pages will rebuild the site automatically.

## Optional
You can replace the text, add your own book cover images, or add more review pages by copying the structure of an existing review page.
