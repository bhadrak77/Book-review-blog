const topButton = document.getElementById('topButton');
if(topButton){
  window.addEventListener('scroll',()=>topButton.classList.toggle('show',window.scrollY>400));
  topButton.addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
}
const year = document.querySelectorAll('[data-year]');
year.forEach(el => el.textContent = new Date().getFullYear());